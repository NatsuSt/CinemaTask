package ua.nure.cinematask.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ua.nure.cinematask.model.Screening;
import ua.nure.cinematask.service.ScreeningService;

import java.util.List;
import java.util.Optional;

@RestController
public class ScreeningController {

    private ScreeningService screeningService;

    @Autowired
    public void setScreeningService(ScreeningService screeningService) {
        this.screeningService = screeningService;
    }

    @GetMapping("/screenings")
    public List<Screening> getScreenings() {
        return screeningService.getScreening();
    }

    @GetMapping("/screenings/{id}")
    public ResponseEntity<?> getScreening(@PathVariable int id) {
        Optional<Screening> screening = screeningService.getScreeningById(id);

        if (screening.isPresent()) {
            return ResponseEntity.ok(screening.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/screenings")
    public Screening createScreening(@RequestBody Screening screening) {
        return screeningService.createScreening(screening);
    }

}
