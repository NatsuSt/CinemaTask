package ua.nure.cinematask.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ua.nure.cinematask.model.Ticket;
import ua.nure.cinematask.service.TicketService;

import java.util.List;

@RestController
public class TicketController {

    private TicketService ticketService;

    @Autowired
    public void setTicketService(TicketService ticketService) {
        this.ticketService = ticketService;
    }

    @PostMapping("/tickets")
    public Ticket createTicket(@RequestBody Ticket ticket) {
        return ticketService.createTicket(ticket);
    }

    @GetMapping("/tickets/by-customer")
    public List<Ticket> getTicketsByCustomer(@RequestParam String customerName) {
        return ticketService.getTicketsByCustomer(customerName);
    }

}